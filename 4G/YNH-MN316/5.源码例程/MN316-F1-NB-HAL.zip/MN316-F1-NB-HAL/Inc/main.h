#ifndef __MAIN_H
#define __MAIN_H

void _Error_Handler( char * file, int line );

/**
 * @}
 */


/**
 * @}
 */

#endif /* __MAIN_H */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
