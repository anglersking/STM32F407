/*
 * **************************************
 * Copyright (c) 2018-2019, Ұţ������.
 *      All rights reserved.
 * **************************************
 */
#include "led.h"

#define LED1_PIN	(GPIO_PIN_5)
#define LED1_GPIO	(GPIOB)

#define LED2_PIN	(GPIO_PIN_5)
#define LED2_GPIO	(GPIOE)

void LED_init()
{
    GPIO_InitTypeDef GPIO_Initure;

    GPIO_Initure.Pin	= LED1_PIN;           /*PF9 */
    GPIO_Initure.Mode	= GPIO_MODE_OUTPUT_PP;
    GPIO_Initure.Pull	= GPIO_PULLUP;
    GPIO_Initure.Speed	= GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init( LED1_GPIO, &GPIO_Initure );
    HAL_GPIO_WritePin( LED1_GPIO, GPIO_PIN_5, GPIO_PIN_RESET );

    GPIO_Initure.Pin	= LED2_PIN;           /*PF10 */
    GPIO_Initure.Mode	= GPIO_MODE_OUTPUT_PP;
    GPIO_Initure.Pull	= GPIO_PULLUP;
    GPIO_Initure.Speed	= GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init( LED2_GPIO, &GPIO_Initure );
    HAL_GPIO_WritePin( LED2_GPIO, LED2_PIN, GPIO_PIN_RESET );
}


u8 LED_set( LED_INDEX index, LED_STATE state )
{
    if ( index == LED_INDEX_1 )
    {
        /*LED1 ��ӦGPIOC.3 */
        if ( state == LED_STATE_OFF )
        {   /*�ر� */
            HAL_GPIO_WritePin( LED1_GPIO, LED1_PIN, GPIO_PIN_SET );
        }
        else if ( state == LED_STATE_ON )
        {   /*�� */
            HAL_GPIO_WritePin( LED1_GPIO, LED1_PIN, GPIO_PIN_RESET );
        }
        else if ( state == LED_STATE_TOGGLE )
        {   /*ȡ�� */
            HAL_GPIO_TogglePin( LED1_GPIO, LED1_PIN );
        }
    }
    else if ( index == LED_INDEX_2 )
    {
        /*LED2 ��ӦGPIOB.1 */
        if ( state == LED_STATE_OFF )
        {   /*�ر� */
            HAL_GPIO_WritePin( LED2_GPIO, LED2_PIN, GPIO_PIN_SET );
        }
        else if ( state == LED_STATE_ON )
        {   /*�� */
            HAL_GPIO_WritePin( LED2_GPIO, LED2_PIN, GPIO_PIN_RESET );
        }
        else if ( state == LED_STATE_TOGGLE )
        {   /*ȡ�� */
            HAL_GPIO_TogglePin( LED2_GPIO, LED2_PIN );
        }
    }
    else
    {
        return (RETURN_ERROR);
    }
    return (RETURN_OK);
}

