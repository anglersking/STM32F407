/*
 * **************************************
 * Copyright (c) 2018-2019, Ұţ������.
 *      All rights reserved.
 * **************************************
 */
#ifndef __LED_H__
#define __LED_H__

#include "system.h"
typedef enum
{
    LED_STATE_INIT,
    LED_STATE_OFF,
    LED_STATE_ON,
    LED_STATE_TOGGLE,
    LED_STATE_END,
}LED_STATE;

typedef enum
{
    LED_INDEX_INIT,
    LED_INDEX_1,
    LED_INDEX_2,
    LED_INDEX_END,
}LED_INDEX;

void LED_init( void );


u8 LED_set( LED_INDEX index, LED_STATE state );


#endif
