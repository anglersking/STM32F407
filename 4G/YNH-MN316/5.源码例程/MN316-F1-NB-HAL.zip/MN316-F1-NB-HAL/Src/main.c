/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include "main.h"
#include "system.h"
#include "Delay.h"
#include "led.h"
#include "user_task.h"
UART_HandleTypeDef huart1;

void        SystemClock_Config( void );
static void MX_GPIO_Init( void );
static void MX_USART1_UART_Init( void );


void SystemClock_Config( void )
{
    RCC_OscInitTypeDef  RCC_OscInitStruct   = { 0 };
    RCC_ClkInitTypeDef  RCC_ClkInitStruct   = { 0 };


    /**Initializes the CPU, AHB and APB busses clocks
     */
    RCC_OscInitStruct.OscillatorType    = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState          = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue    = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState          = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState      = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource     = RCC_PLLSOURCE_HSE;
#if RCC_CLK == 8
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
#elif RCC_CLK == 12
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
#endif
    if ( HAL_RCC_OscConfig( &RCC_OscInitStruct ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }


    /**Initializes the CPU, AHB and APB busses clocks
     */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                  | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource      = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider     = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider    = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider    = RCC_HCLK_DIV1;

    if ( HAL_RCC_ClockConfig( &RCC_ClkInitStruct, FLASH_LATENCY_2 ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }
}


static void MX_USART1_UART_Init( void )
{
    huart1.Instance             = USART1;
    huart1.Init.BaudRate        = 115200;
    huart1.Init.WordLength      = UART_WORDLENGTH_8B;
    huart1.Init.StopBits        = UART_STOPBITS_1;
    huart1.Init.Parity          = UART_PARITY_NONE;
    huart1.Init.Mode            = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl       = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling    = UART_OVERSAMPLING_16;
    if ( HAL_UART_Init( &huart1 ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }
}


void MX_GPIO_Init( void )
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
}


extern uint32_t create_work_test( NBAppDemoPath_t protocolType );


int main( void )
{
    HAL_Init();
    SystemClock_Config();
    DELAY_init( 72 );
    MX_GPIO_Init();
    MX_USART1_UART_Init();

    printf( "**********************Welcome NBIOT**********************\r\n" );
    printf( "*************************Demo****************************\r\n" );
    DELAY_ms( 100 );


    /*
     * �޸�protocolType,�ֱ����ִ��UDP/TCP/MQTT/OneNet/������
     * ͬʱע��Խӵ�Э����Ҫ�޸���궨�������
     * ����MQTT��Ҫ�޸�
     * DEMO_MQTT_BrokerAddress �Ⱥ궨��
     * NBDemoPath_UDP      ����UDP     ��ʾ
     * NBDemoPath_TCP      ����TCP     ��ʾ
     * NBDemoPath_MQTT     ����MQTT    ��ʾ
     * NBDemoPath_ONENET   ����ONENET  ��ʾ
     * NBDemoPath_ALIYUN   ���ڰ�����  ��ʾ
     */
    NBAppDemoPath_t protocolType = NBDemoPath_UDP;
    create_work_test( protocolType );
    while ( 1 )
        ;
}


void _Error_Handler( char * file, int line )
{
    printf( "[ERROR]_Error_Handler...\r\n" );
    while ( 1 )
    {
        ;
    }
}

