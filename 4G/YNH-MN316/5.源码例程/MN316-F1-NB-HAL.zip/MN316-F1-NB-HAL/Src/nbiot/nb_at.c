/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include <stdio.h>
#include <string.h>
#include "nb_api.h"
#include "nb_mn316.h"
#include "system.h"
#include "string.h"
#include "nb_at.h"

static UART_HandleTypeDef   huartx;
static TIM_HandleTypeDef    htimx;
static uint16_t             uartxRxstate    = 0;
static uint16_t             uartxTxstate    = 0;
static uint8_t              uartxRxBuf[512];
static uint8_t              uartxTxBuf[512];
static uint8_t              aRxBuffer[128];
static const struct at_urc  *gUrcTable;
static uint8_t              gUrcTableSize;

uint8_t NBAT_checkUrc( uint8_t *outResponse, uint32_t len );


#define    UARTX_RECV_END (0x8000)

void HAL_UART_RxCpltCallback( UART_HandleTypeDef *huart )
{
    HAL_UART_Receive_IT( &huartx, (uint8_t *) &aRxBuffer, 1 ); /*�ٿ��������ж� */
}


void USART2_IRQHandler( void )
{
    if ( huartx.Instance == USART2 )
    {
        uint8_t     res;
        uint32_t    flage = (&huartx)->Instance->SR;
        if ( (__HAL_UART_GET_FLAG( &huartx, UART_FLAG_ORE ) != RESET) )
        {   /*��� */
            __HAL_UART_CLEAR_OREFLAG( &huartx );
        }
        if ( (__HAL_UART_GET_FLAG( &huartx, UART_FLAG_PE ) != RESET) )
        {
            __HAL_UART_CLEAR_PEFLAG( &huartx );
        }
        if ( (__HAL_UART_GET_FLAG( &huartx, UART_FLAG_FE ) != RESET) )
        {
            __HAL_UART_CLEAR_FEFLAG( &huartx );
        }
        if ( (__HAL_UART_GET_FLAG( &huartx, UART_FLAG_NE ) != RESET) )
        {
            __HAL_UART_CLEAR_NEFLAG( &huartx );
        }

        if ( (__HAL_UART_GET_FLAG( &huartx, UART_FLAG_RXNE ) != RESET) )
        {
            /*printf( "a" ); */
            res = (uint8_t) (huartx.Instance->DR & (uint16_t) 0x00FF);
            if ( (uartxRxstate & UARTX_RECV_END) == 0 )
            {
                if ( uartxRxstate == 0x00 )
                {
                    memset( (uint8_t *) uartxRxBuf, 0x00, sizeof(uartxRxBuf) );
                }
                if ( uartxRxstate < sizeof(uartxRxBuf) )
                {
                    TIM2->CNT = 0;                          /*��������� */
                    HAL_TIM_Base_Start( &htimx );
                    uartxRxBuf[uartxRxstate++] = res;       /*��¼���յ���ֵ */
                }
                else
                {
                    uartxRxstate |= UARTX_RECV_END;         /*ǿ�Ʊ�ǽ������ */
                }
            }
        }
    }
    HAL_UART_Receive_IT( &huartx, (uint8_t *) &aRxBuffer, 1 );
}


void TIM2_IRQHandler( void )
{
    /*printf("[INFO]timeout\r\n"); */
    if ( (uartxRxstate & 0x7FFF) != 0 )
    {
        if ( uartxTxstate == 1 )
            uartxRxstate |= UARTX_RECV_END; /*ָ����Ӧ */
        else if ( uartxTxstate == 0 )
        {
            /*���URC */
            NBAT_checkUrc( uartxRxBuf, uartxRxstate );
        }
    }
    HAL_TIM_IRQHandler( &htimx );
    HAL_TIM_Base_Stop( &htimx );
}


/*3ms��ʱ�� */
static void TIM2_init( void )
{
    TIM_MasterConfigTypeDef sMasterConfig;

    htimx.Instance              = TIM2;
    htimx.Init.Prescaler        = 10 * 72 - 1;  /*10us */
    htimx.Init.CounterMode      = TIM_COUNTERMODE_UP;
    htimx.Init.Period           = 100 * 3 - 1;  /*3ms */
    htimx.Init.ClockDivision    = TIM_CLOCKDIVISION_DIV1;
    if ( HAL_TIM_Base_Init( &htimx ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }

    sMasterConfig.MasterOutputTrigger   = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode       = TIM_MASTERSLAVEMODE_DISABLE;
    if ( HAL_TIMEx_MasterConfigSynchronization( &htimx, &sMasterConfig ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }
    HAL_TIM_Base_Start_IT( &htimx );
}


void UARTx_init( UART_HandleTypeDef *huart )
{
    if ( HAL_UART_Init( huart ) != HAL_OK )
    {
        _Error_Handler( __FILE__, __LINE__ );
    }

    /*���ж� */
    __HAL_UART_ENABLE_IT( huart, UART_IT_PE );
    __HAL_UART_ENABLE_IT( huart, UART_IT_ERR );
    __HAL_UART_ENABLE_IT( huart, UART_IT_RXNE );

    HAL_NVIC_SetPriority( USART2_IRQn, 0, 0 );
    HAL_NVIC_EnableIRQ( USART2_IRQn );
}


void UARTx_write( uint8_t *buf, uint16_t length )
{
    uint16_t i;
    for ( i = 0; i < length; i++ )  /*ѭ���������� */
    {
        while ( (huartx.Instance->SR & 0x40) == 0 )
            ;
        huartx.Instance->DR = buf[i];
    }
}


void NBAT_init( UART_HandleTypeDef *huart )
{
    UARTx_init( huart );
    TIM2_init();
}


char* NBAT_checkCmd( char *str )
{
    char *strx = 0;
    if ( uartxRxstate & UARTX_RECV_END )
    {                                               /*���յ�һ�������� */
        uartxRxBuf[uartxRxstate & 0x7FFF]   = 0;    /*���ӽ����� */
        strx                                = (char *) strstr( (const char *) uartxRxBuf, (const char *) str );
    }
    return (strx);
}


int NBAT_sendBuf( char *buf, char *ack, uint32_t waittime, uint8_t *outResponse )
{
    uint8_t     res     = 0;
    uint16_t    sendLen = 0;
    if ( strlen( buf ) > sizeof(uartxTxBuf) )
    {
        printf( "NBAT_sendCmd Len is %d\r\n", strlen( buf ) );
        return (2);
    }
    /*��Ϊ0��ʾ��URC���ݽ��� */
    while ( uartxRxstate != 0 )
        ;

    /*���ͱ�־λ��λ */
    uartxTxstate = 1;

    sendLen = sprintf( (char *) uartxTxBuf, "%s", buf );
    UARTx_write( uartxTxBuf, sendLen );

    waittime *= 10 * 100;
    if ( ack && waittime )
    {
        while ( --waittime )
        {
            DELAY_us( 10 );
            if ( uartxRxstate & UARTX_RECV_END )
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    if ( outResponse != NULL )
                    {
                        memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                        outResponse[uartxRxstate & 0x7FFF] = 0;
                    }
                    /*�õ���Ч���� */
                    uartxRxstate = 0;
                    break;
                }
            }
        }
        if ( waittime == 0 )
            res = 1;
    }
    uartxRxstate    = 0;
    uartxTxstate    = 0;
    return (res);
}


uint8_t NBAT_sendCmd( char *cmd, char *ack, uint32_t waittime, uint8_t *outResponse )
{
    uint8_t     res     = 0;
    uint16_t    sendLen = 0;
    if ( strlen( cmd ) > sizeof(uartxTxBuf) )
    {
        printf( "NBAT_sendCmd Len is %d\r\n", strlen( cmd ) );
        return (2);
    }
    /*��Ϊ0��ʾ��URC���ݽ��� */
    while ( uartxRxstate != 0 )
        ;
    uartxTxstate = 1;                                           /*���ͱ�־λ��λ */

    sendLen = sprintf( (char *) uartxTxBuf, "%s", cmd );
    UARTx_write( uartxTxBuf, sendLen );                         /*�������� */
    UARTx_write( AT_LINE_END, strlen( AT_LINE_END ) - 1 );      /*���ͽ������� */

    waittime *= 10 * 100;
    if ( ack && waittime )                                      /*��Ҫ�ȴ�Ӧ�� */
    {
        while ( --waittime )                                    /*�ȴ�����ʱ */
        {
            DELAY_us( 10 );
            if ( uartxRxstate & UARTX_RECV_END )                /*���յ��ڴ���Ӧ���� */
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    if ( outResponse != NULL )
                    {
                        memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                        outResponse[uartxRxstate & 0x7FFF] = 0;
                    }
                    uartxRxstate = 0;
                    /*�õ���Ч���� */
                    break;
                }
            }
        }
        if ( waittime == 0 )
            res = 1;
    }
    uartxRxstate    = 0;
    uartxTxstate    = 0;
    return (res);
}


uint8_t NBAT_checkUrc( uint8_t *outResponse, uint32_t len )
{
    uint8_t idx;
    uint8_t *strPtr     = outResponse;
    uint8_t strLen      = 0;
    char    * strStart  = NULL;
    char    * strEnd    = NULL;
    /*printf( "NBAT_checkUrc:" ); */
    for ( idx = 0; idx < gUrcTableSize; idx++ )
    {
        strStart = strstr( (char *) strPtr, gUrcTable[idx].cmd_prefix );
        if ( strStart != 0 )
        {
            strLen  = strlen( gUrcTable[idx].cmd_prefix );
            strEnd  = strstr( (char *) strPtr + strLen, gUrcTable[idx].cmd_suffix );
            strLen  = strEnd - strStart + strlen( gUrcTable[idx].cmd_suffix );
            if ( strEnd != 0 )
                gUrcTable[idx].func( (const char *) strPtr, strLen );
            strPtr += strLen;
        }
    }
    uartxRxstate = 0;   /*�����URC֮������ */
    return (1);
}


uint8_t NBAT_recvData( char *ack, uint16_t waittime, uint8_t *outResponse )
{
    uint8_t res = 0;
    if ( (uartxRxstate & UARTX_RECV_END) == 0 )
        return (2);
    if ( ack && waittime )                              /*��Ҫ�ȴ�Ӧ�� */
    {
        /*�ȴ�����ʱ */
        do
        {
            DELAY_ms( 10 );
            if ( uartxRxstate & UARTX_RECV_END )        /*���յ��ڴ���Ӧ���� */
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                    outResponse[uartxRxstate & 0x7FFF]  = 0;
                    uartxRxstate                        = 0;
                    break;                              /*�õ���Ч���� */
                }
            }
        }
        while ( --waittime );
        if ( waittime == 0 )
            res = 1;
    }
    return (res);
}


/*static at_response_t resp = RT_NULL; */
int32_t at_init( at_config *config )
{
    memset( &huartx, 0x00, sizeof(UART_HandleTypeDef) );
    /*��ʱֻ֧��UART2������ */
    if ( config->usart_port == 2 )
        huartx.Instance = USART2;
    else
        return (-1);

    if ( config->buardrate == 9600 )
    {
        huartx.Init.BaudRate = 9600;
    }
    else if ( config->buardrate == 115200 )
    {
        huartx.Init.BaudRate = 115200;
    }
    else
    {
        return (-1);
    }

    huartx.Init.WordLength      = UART_WORDLENGTH_8B;
    huartx.Init.StopBits        = UART_STOPBITS_1;
    huartx.Init.Parity          = UART_PARITY_NONE;
    huartx.Init.Mode            = UART_MODE_TX_RX;
    huartx.Init.HwFlowCtl       = UART_HWCONTROL_NONE;
    huartx.Init.OverSampling    = UART_OVERSAMPLING_16;
    NBAT_init( &huartx );
    return (0);
}


int32_t at_deinit( void )
{
    return (0);
}


int32_t at_cmd( int8_t *cmd, int32_t len, const char *suffix, char *resp_buf, int* resp_len )
{
    uint32_t    recvLen = 0;
    int         result;
    result = NBAT_sendCmd( (char *) cmd, (char *) suffix, 100, (uint8_t *) resp_buf );
    return (result);
}


int32_t at_buf( int8_t *buf, int32_t len, const char *suffix, char *resp_buf, int* resp_len )
{
    uint32_t    recvLen = 0;
    int         result;
    result = NBAT_sendBuf( (char *) buf, (char *) suffix, 100, (uint8_t *) resp_buf );
    return (result);
}


int32_t at_set_urc_table( const struct at_urc *urc_table, uint32_t table_sz )
{
    uint8_t idx;

    if ( table_sz > 5 )
        return (-1);
    for ( idx = 0; idx < table_sz; idx++ )
    {
        if ( urc_table[idx].cmd_prefix == NULL || urc_table[idx].cmd_suffix == NULL )
        {
            printf( "[ERROR]at_set_urc_table fail\r\n" );
            return (-2);
        }
    }
    gUrcTable       = urc_table;
    gUrcTableSize   = table_sz;
    return (0);
}


at_task at =
{
    .init       = at_init,
    .deinit     = at_deinit,
    .cmd        = at_cmd,
    .sendBuf    = at_buf,
};

