/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#ifndef __NB_MN316_H__
#define __NB_MN316_H__

#include "nb_at.h"

#define AT_MODU_NAME    "MN316"
#define AT_NB_LINE_END  "\r\n"
#define AT_NB_at        "AT"
#define AT_NB_pwrdown   "AT+NRB"
#define AT_NB_hw_detect "AT+CFUN?\r"
#define AT_CMD_PREFIX   "\r\n+NNMI:"
#define AT_DATAF_PREFIX "+NSONMI:"
#define CGATT           "AT+CGATT?\r"
#define CGATT_ATTACH    "AT+CGATT=1\r"
#define CGATT_DEATTACH  "AT+CGATT=0\r"

#define AT_LINE_END     "\r\n"
#define AT_CMD_BEGIN    "\r\n"


#define AT_USART_PORT   2
#define AT_BUARDRATE    9600
#define AT_CMD_TIMEOUT  2000      /*ms */
#define AT_MAX_LINK_NUM 4

#define NB_STAT_LOCALPORT 56


#define MAX_SOCK_NUM    5
#define UDP_PROTO       17


#if defined STM32F103xE
    #define MAX_AT_USERDATA_LEN (1024 * 2)
#else
    #define MAX_AT_USERDATA_LEN (1024 * 5)
#endif

#define AT_MAX_PAYLOADLEN 512


int str_to_hex( const char *bufin, int len, char *bufout );


int32_t NB_checkDevice( void );
int32_t NB_setATI( uint8_t enable );
int32_t NB_pwrdown( void );
int32_t NB_getCimi( void );
int32_t NB_getCGSN( void );
int32_t NB_detect( void );
int32_t NB_checkCsq( void );

int32_t NB_CIMI( void );
int32_t NB_netstat( void );
int32_t NB_queryIp( void );
int32_t NB_getCereg( void );
int32_t NB_MN316_setLowPower( uint8_t enable );

int32_t NB_MN316_socketCreate( uint8_t socketId, char* host, uint16_t port, int proto );
int32_t NB_MN316_socketStrSend( int32_t socketId, const char  *inData, uint32_t len, char* host, uint16_t port, int proto );
int32_t NB_MN316_socketStrRecv( int32_t socketId, char  *outData, uint32_t len );
int32_t NB_MN316_sockClose( int32_t socketId );

int32_t NB_MN316_mqttOpen( char* protocolVer );
int32_t NB_MN316_mqttConnet( char *brokerAddress, uint16_t port,
                             char *clientID, char * userName, char * password );
int32_t NB_MN316_mqttSub( char* topic );
int32_t NB_MN316_mqttPub( char* topic, char* msg, uint32_t msgLen );
int32_t NB_MN316_mqttPubEX( char* topic, char* msg, uint32_t msgLen );


#endif

