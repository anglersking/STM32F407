/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "nb_api.h"
#include "nb_mn316.h"
#include "user_task.h"

static uint32_t g_nb_tskHandle;
#define DEMO_UDP_HOST   "123.207.210.43"
#define DEMO_UDP_PORT   (9999)

#define DEMO_TCP_HOST   "123.207.210.43"
#define DEMO_TCP_PORT   (8888)

#define DEMO_MQTT_HOST      "123.207.210.43"
#define DEMO_MQTT_PORT      (1883)
#define DEMO_MQTT_Cient_ID  "clientExample_1234"
#define DEMO_MQTT_UserName  ""
#define DEMO_MQTT_Password  ""
#define DEMO_MQTT_TOPIC     "topic/example_8808"

#define DEMO_ONNET_brokerAddress    "183.230.40.96"
#define DEMO_ONNET_port             (1883)
#define DEMO_ONNET_cientId          "EC800816"
#define DEMO_ONNET_userName         "WtF1aQE659"
#define DEMO_ONNET_password         "version=2018-10-31&res=products%2FWtF1aQE659%2Fdevices%2FEC800816&et=2537256630&method=md5&sign=VJfBWuWM43wPgj%2BH7B0G8w%3D%3D"
#define DEMO_ONNET_pubtopic         "$sys/WtF1aQE659/EC800816/thing/property/post"
#define DEMO_ONNET_subtopic         "$sys/WtF1aQE659/EC800816/thing/property/set"

#define DEMO_ALIYUN_brokerAddress   "iot-06z00f8bo0pxsix.mqtt.iothub.aliyuncs.com"
#define DEMO_ALIYUN_port            (1883)
#define DEMO_ALIYUN_cientId         "k0jupm3hCdL.ML307842|securemode=2,signmethod=hmacsha256,timestamp=1701254764452|"
#define DEMO_ALIYUN_userName        "ML307842&k0jupm3hCdL"
#define DEMO_ALIYUN_password        "3d6c79c780d8923307a9ac2b00a57b5881fc4950d13389f8bc2c18fd84b6e3ef"
#define DEMO_ALIYUN_pubtopic        "/sys/k0jupm3hCdL/ML307842/thing/event/property/post"
#define DEMO_ALIYUN_subtopic        "/sys/k0jupm3hCdL/ML307842/thing/event/property/set"

uint8_t g_connetOkFlage         = 0;
uint8_t g_mqttOpenOkFlage       = 0;
uint8_t g_mqttConnetOkFlage     = 0;
uint8_t g_coapConnetEvent       = 0;
uint8_t g_onenetConnetEvent     = 0;
uint8_t g_aliyunOpenOkFlage     = 0;
uint8_t g_aliyunConnetOkFlage   = 0;

uint32_t g_socketRecvLen = 0;

void nb_urc_dataIoctl( const char *buf, unsigned long size )
{
    char    recvData[128];
    int     recvLen;
    int     socketId;
    printf( "\r\n[INFO]nb_urc_dataIoctl!\r\n" );
    memset( recvData, 0, 128 );
    if ( strstr( (char *) buf, "+NSONMI" ) != NULL )
    {
        /*�յ�������*/
        sscanf( (char *) buf, "\r\n+NSONMI:%d,%d\r\n", &socketId, &recvLen );
        printf( "[INFO]SocketId:%d,RecvLen:%d\r\n", socketId, recvLen );
        g_socketRecvLen = recvLen;
    }
    else if ( strstr( (char *) buf, "CONNECT OK" ) != NULL )
    {
        printf( "[INFO]connet success\r\n" );
        g_connetOkFlage = 1;
    }
}


static struct at_urc    nb_urc_table[] = {
    { "\r\nCONNECT", "\r\n", nb_urc_dataIoctl },
    { "\r\n+NSONMI", "\r\n", nb_urc_dataIoctl }
};
char                    sendData[128];
char                    recvData[128];
void nb_udp_task_entry( void )
{
    uint32_t    uwRet   = 0;
    int32_t     atRet   = AT_FAILED;
    uint32_t    count   = 0;

    printf( "[INFO]This is nb_udp_task_entry!\r\n" );
    g_connetOkFlage = 0;
    g_socketRecvLen = 0;
    nb_urc_set( nb_urc_table, sizeof(nb_urc_table) / sizeof(nb_urc_table[0]) );
    atRet = nb_soctet_init( 0, (const char *) DEMO_UDP_HOST, DEMO_UDP_PORT, 17 );
    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_soctet_init fail \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        if ( g_socketRecvLen != 0 )
        {
            nb_socket_recv( 0, recvData, g_socketRecvLen );
            g_socketRecvLen = 0;
        }
        sprintf( sendData, "hello.yeniuiot.count=%d", count );
        printf( "[INFO]*****************************************\r\n" );
        printf( "[INFO]Udp send-->%s", sendData );
        count++;
        nb_socket_report( 0, sendData, strlen( sendData ) );
        uwRet = DelayMs( 5000 );
        if ( uwRet != 0 )
            return;
        if ( count > 10 )
            break;
    }
}


void nb_tcp_task_entry( void )
{
    uint32_t    uwRet   = 0;
    int32_t     atRet   = AT_FAILED;
    uint32_t    count   = 0;
    g_connetOkFlage = 0;
    nb_urc_set( nb_urc_table, sizeof(nb_urc_table) / sizeof(nb_urc_table[0]) );
    printf( "[INFO]This is nb_tcp_task_entry!\r\n" );
    atRet = nb_soctet_init( 0, (const char *) DEMO_TCP_HOST, DEMO_TCP_PORT, 6 );
    if ( atRet != 0 )
    {
        printf( "[INFO]nb_soctet_init fail \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        if ( g_connetOkFlage == 1 )
            break;
        uwRet = DelayMs( 1000 );
        if ( uwRet != 0 )
            return;
        if ( count > 120 )
        {
            printf( "[ERROR]Tcp soctet connect timeout \r\n" );
            return;
        }
        count++;
    }
    count = 0;
    while ( 1 )
    {
        if ( g_socketRecvLen != 0 )
        {
            nb_socket_recv( 0, recvData, g_socketRecvLen );
            g_socketRecvLen = 0;
        }
        sprintf( sendData, "hello.yeniuiot.count=%d", count );
        printf( "\r\n" );
        printf( "[INFO]*****************************************\r\n" );
        printf( "[INFO]Tcp send-->%s", sendData );
        count++;
        nb_socket_report( 0, sendData, strlen( sendData ) );
        uwRet = DelayMs( 5000 );
        if ( uwRet != 0 )
            return;
        if ( count > 10 )
            break;
    }
}


void nb_mqtt_dataIoctl( const char *buf, unsigned long size )
{
    char    recvData[256];
    int     recvLen;
    int     socketId;
    printf( "[INFO]This is nb_mqtt_dataIoctl!\r\n" );
    memset( recvData, 0, 256 );
    memcpy( recvData, buf, size );

    if ( strstr( (char *) recvData, "+MQTTOPEN:OK" ) != NULL )
    {
        g_mqttConnetOkFlage = 1;
    }
    else if ( strstr( (char *) recvData, "+MQTTPUBLISH:" ) != NULL )
    {
        printf( "[INFO]MQTT RECV success!\r\n" );
        printf( "%s", recvData );
    }
}


static struct at_urc mqtt_urc_table[] = {
    { "+MQTTOPEN:",    "\r\n", nb_mqtt_dataIoctl },
    { "+MQTTPUBLISH:", "\r\n", nb_mqtt_dataIoctl },
};

void nb_mqtt_task_entry( void )
{
    uint32_t    uwRet = 0;
    int32_t     atRet = AT_FAILED;
    uint32_t    count = 0;
    float       temp = 24, ill = 54.0, light = 26.0;
    char        sendData[256];

    printf( "[INFO]This is nb_mqtt_task_entry!\r\n" );
    g_mqttOpenOkFlage = 0;
    nb_urc_set( mqtt_urc_table, sizeof(mqtt_urc_table) / sizeof(mqtt_urc_table[0]) );
    /*1.1�� */
    atRet = nb_mqtt_init( NULL );

    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_init fail \r\n" );
        return;
    }

    /*1.2���� */
    g_mqttConnetOkFlage = 0;
    atRet               = nb_mqtt_conn( DEMO_MQTT_HOST, DEMO_MQTT_PORT, DEMO_MQTT_Cient_ID, NULL, NULL );
    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_conn fail \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        if ( g_mqttConnetOkFlage == 1 )
        {
            printf( "[INFO]Mqtt connect success!\r\n" );
            break;
        }
        uwRet = DelayMs( 1000 );
        if ( uwRet != 0 )
            return;
        if ( count > 120 )
        {
            printf( "[ERROR]Mqtt connect timeout \r\n" );
            return;
        }
    }

    /*1.3������Ϣ */
    uwRet = nb_mqtt_sub( DEMO_MQTT_TOPIC );
    if ( uwRet != 0 )
    {
        printf( "[ERROR]Mqtt Subscriber error \r\n" );
        return;
    }

    /*1.4������Ϣ */
    count = 0;
    while ( 1 )
    {
        count++;
        /*������� */
        sprintf( sendData, "hello yeniu!I am MN316,cnt%d!", count );
        printf( "\r\n" );
        printf( "[INFO]*****************************************\r\n" );
        printf( "[INFO]MQTT publish-->%s\r\n", sendData );

        nb_mqtt_pub( DEMO_MQTT_TOPIC, sendData );
        uwRet = DelayMs( 5000 );
        if ( uwRet != 0 )
            return;
        if ( count > 10 )
            break;
    }
}


void nb_onenet_dataIoctl( const char *buf, unsigned long size )
{
    char    recvData[256];
    int     recvLen;
    int     socketId;
    printf( "[INFO]This is nb_onenet_dataIoctl!\r\n" );
    memset( recvData, 0, 256 );
    memcpy( recvData, buf, size );

    if ( strstr( (char *) recvData, "+MQTTOPEN:OK" ) != NULL )
    {
        g_mqttConnetOkFlage = 1;
    }
    else if ( strstr( (char *) recvData, "+MQTTPUBLISH:" ) != NULL )
    {
        printf( "[INFO]MQTT RECV success!\r\n" );
        printf( "%s", recvData );
    }
}


static struct at_urc onenet_urc_table[] = {
    { "+MQTTOPEN:",    "\r\n", nb_mqtt_dataIoctl },
    { "+MQTTPUBLISH:", "\r\n", nb_mqtt_dataIoctl },
};

void nb_onenet_task_entry( void )
{
    uint32_t    uwRet   = 0;
    int32_t     atRet   = AT_FAILED;
    uint32_t    count   = 0;
    char        sendData[256];
    float       temp = 24, ill = 54.0, light = 26.0;

    printf( "[INFO]This is nb_onenet_task_entry!\r\n" );
    /*1.1�� */
    nb_urc_set( onenet_urc_table, sizeof(onenet_urc_table) / sizeof(onenet_urc_table[0]) );
    atRet = nb_mqtt_init( "3.1.1" );

    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_init fail \r\n" );
        return;
    }

    /*1.2���� */
    g_mqttConnetOkFlage = 0;
    atRet               = nb_mqtt_conn( DEMO_ONNET_brokerAddress, DEMO_ONNET_port,
                                        DEMO_ONNET_cientId, DEMO_ONNET_userName, DEMO_ONNET_password );
    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_conn fail \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        if ( g_mqttConnetOkFlage == 1 )
        {
            printf( "[INFO]onenet Mqtt connect success!\r\n" );
            break;
        }
        uwRet = DelayMs( 1000 );
        if ( uwRet != 0 )
            return;
        if ( count > 120 )
        {
            printf( "[ERROR]onenet Mqtt connect timeout \r\n" );
            return;
        }
    }

    /*1.3������Ϣ */
    uwRet = nb_mqtt_sub( DEMO_ONNET_subtopic );
    if ( uwRet != 0 )
    {
        printf( "[ERROR]onenet Mqtt Subscriber error \r\n" );
        return;
    }

    g_onenetConnetEvent = 0;
    count               = 0;
    while ( 1 )
    {
        count++;
        /*����sendData */
        /*{"id":"123","version":"1.0","params":{"CurrentTemperature":{"value":11.3},"LightLux":{"value":1000.3},"SoilMoisture":{"value":51.4}}} */
        sprintf( sendData, "{\
\"id\":\"1234\",\
\"version\":\"1.0\",\
\"params\":{\
\"CurrentTemperature\":{\"value\":%2.1f},\
\"LightLux\":{\"value\":%3.1f},\
\"SoilMoisture\":{\"value\":%2.1f}}\
}", temp, light, ill );
        printf( "\r\n" );
        printf( "[INFO]*****************************************\r\n" );
        printf( "[INFO]Onenet send %d-->%s\r\n", count, sendData );
        uwRet = nb_mqtt_pub( DEMO_ONNET_pubtopic, sendData );
        if ( uwRet != 0 )
            return;
        DelayMs( 5000 );

        temp    += 0.1;
        temp    = temp > 38.0 ? 24.0 : temp;

        light   += 0.1;
        light   = light > 99.9 ? 24.0 : light;

        ill += 0.1;
        ill = ill > 99.9 ? 24.0 : ill;

        if ( count > 10 )
            break;
    }
}


void nb_aliyun_dataIoctl( const char *buf, unsigned long size )
{
    char    recvData[256];
    int     recvLen;
    int     socketId;
    printf( "[INFO]This is nb_aliyun_dataIoctl!\r\n" );
    memset( recvData, 0, 256 );
    memcpy( recvData, buf, size );

    if ( strstr( (char *) recvData, "+MQTTOPEN:OK" ) != NULL )
    {
        g_aliyunConnetOkFlage = 1;
    }
    else if ( strstr( (char *) recvData, "+MQTTPUBLISH:" ) != NULL )
    {
        printf( "[INFO]MQTT RECV success!\r\n" );
        printf( "%s", recvData );
    }
}


static struct at_urc aliyun_urc_table[] = {
    { "+MQTTOPEN:",    "\r\n", nb_aliyun_dataIoctl },
    { "+MQTTPUBLISH:", "\r\n", nb_aliyun_dataIoctl },
};

void nb_aliyun_task_entry( void )
{
    uint32_t    uwRet   = 0;
    int32_t     atRet   = AT_FAILED;
    uint32_t    count   = 0;
    char        sendData[256];
    float       temp = 24, ill = 54.0, light = 26.0;

    printf( "[INFO]This is nb_aliyun_task_entry!\r\n" );
    /*1.1�� */
    nb_urc_set( aliyun_urc_table, sizeof(aliyun_urc_table) / sizeof(aliyun_urc_table[0]) );
    atRet = nb_mqtt_init( "3.1.1" );

    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_init fail \r\n" );
        return;
    }

    /*1.2���� */
    g_aliyunConnetOkFlage   = 0;
    atRet                   = nb_mqtt_conn( DEMO_ALIYUN_brokerAddress, DEMO_ALIYUN_port,
                                            DEMO_ALIYUN_cientId, DEMO_ALIYUN_userName, DEMO_ALIYUN_password );
    if ( atRet != 0 )
    {
        printf( "[ERROR]nb_mqtt_conn fail \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        if ( g_aliyunConnetOkFlage == 1 )
        {
            printf( "[INFO]aliyun Mqtt connect success!\r\n" );
            break;
        }
        uwRet = DelayMs( 1000 );
        if ( uwRet != 0 )
            return;
        if ( count > 120 )
        {
            printf( "[ERROR]aliyun Mqtt connect timeout \r\n" );
            return;
        }
    }

    /*1.3������Ϣ */
    uwRet = nb_mqtt_sub( DEMO_ALIYUN_subtopic );
    if ( uwRet != 0 )
    {
        printf( "[ERROR]aliyun Mqtt Subscriber error \r\n" );
        return;
    }

    count = 0;
    while ( 1 )
    {
        count++;
        /*����sendData */
        /*{params:{CurrentTemperature:51.8,RelativeHumidity:37,LightLuxValue:56.3}} */
        sprintf( sendData, "{\
\"params\":{\
\"CurrentTemperature\":%2.1f,\
\"LightLuxValue\":%3.1f,\
\"RelativeHumidity\":%2.1f}\
}", temp, light, ill );
        printf( "\r\n" );
        printf( "[INFO]*****************************************\r\n" );
        printf( "[INFO]aliyun send %d-->%s\r\n", count, sendData );
        uwRet = nb_mqtt_pub( DEMO_ALIYUN_pubtopic, sendData );
        if ( uwRet != 0 )
            return;
        DelayMs( 5000 );

        temp    += 0.1;
        temp    = temp > 38.0 ? 24.0 : temp;

        light   += 0.1;
        light   = light > 99.9 ? 24.0 : light;

        ill += 0.1;
        ill = ill > 99.9 ? 24.0 : ill;

        if ( count > 10 )
            break;
    }
}


uint32_t nb_task( NBAppDemoPath_t protocolType )
{
    uint32_t    uwRet = 0;
    char        taskName[32];
    void        (*threadnb_entry)();

    if ( protocolType == NBDemoPath_UDP )
    {
        memcpy( taskName, "nb_udp_task", strlen( "nb_udp_task" ) );
        threadnb_entry = nb_udp_task_entry;
    }
    else if ( protocolType == NBDemoPath_TCP )
    {
        memcpy( taskName, "nb_tcp_task", strlen( "nb_tcp_task" ) );
        threadnb_entry = nb_tcp_task_entry;
    }
    else if ( protocolType == NBDemoPath_MQTT )
    {
        memcpy( taskName, "nb_mqtt_task", strlen( "nb_mqtt_task" ) );
        threadnb_entry = nb_mqtt_task_entry;
    }
    else if ( protocolType == NBDemoPath_ONENET )
    {
        memcpy( taskName, "nb_onenet_task", strlen( "nb_onenet_task" ) );
        threadnb_entry = nb_onenet_task_entry;
    }
    else if ( protocolType == NBDemoPath_ALIYUN )
    {
        memcpy( taskName, "nb_aliyun_task", strlen( "nb_aliyun_task" ) );
        threadnb_entry = nb_aliyun_task_entry;
    }
    threadnb_entry();
    return (uwRet);
}


uint32_t create_work_test( NBAppDemoPath_t protocolType )
{
    uint32_t uwRet = 0;    
    uwRet           = nb_task( protocolType );
    if ( uwRet != 0 )
    {
        return (0);
    }
    return (uwRet);
}

