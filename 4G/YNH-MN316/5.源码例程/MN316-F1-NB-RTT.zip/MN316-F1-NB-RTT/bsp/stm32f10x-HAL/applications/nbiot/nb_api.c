/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include "nb_api.h"
#include "nb_mn316.h"
static char     g_host[32];
static uint16_t g_port;
static uint16_t g_proto;
/*ģ���ϵ�ͨ�ó�ʼ�� */
int nb_comm_init()
{
    int ret;
    int timecnt = 0;

    at_config at_user_conf = {
        .name			= AT_MODU_NAME,
        .usart_port		= AT_USART_PORT,
        .buardrate		= AT_BUARDRATE,
        .user_buf_len	= MAX_AT_USERDATA_LEN,
        .cmd_begin		= AT_CMD_BEGIN,
        .line_end		= AT_LINE_END,
        .mux_mode		= 1,    /*support multi connection mode */
        .timeout		= 2000, /*  ms */
    };

    at.init( &at_user_conf );

    ret = NB_checkDevice();

    /*��λģ�� */
    ret = NB_pwrdown();

    for ( timecnt = 1; timecnt <= 8; timecnt++ )
    {
        printf( "[INFO]Waiting power on %d\n", timecnt );
        DelayMs( 1000 );
    }

    while ( 1 )
    {
        ret = NB_checkDevice();
        if ( ret == AT_OK )
            break;
        DelayMs( 500 );
    }
    NB_setATI( 0 );             /*�رջ��� */
    ret = 0;
    while ( 1 )
    {
        ret = 0;
        ret |= NB_getCimi();
        ret |= NB_getCGSN();

        if ( ret == AT_OK )
            break;
        DelayMs( 500 );
    }

    /*�ȴ�ע���ɹ� */
    while ( timecnt < 120 )
    {
        ret = NB_netstat();
        printf( "[INFO]Waiting for join network\n" );
        printf( "[INFO]NB_netstat\n" );
        ret = NB_checkCsq();
        printf( "[INFO]NB_checkCsq\n" );
        ret = NB_getCereg();
        printf( "[INFO]NB_getCereg \n" );
        ret |= NB_queryIp();
        if ( ret == AT_OK )
        {
            break;
        }
        DelayMs( 500 );
        timecnt++;
    }
    printf( "[INFO]Join network success!\n" );
    ret |= NB_getCereg();

    if ( ret < 0 )
    {
        printf( "[ERROR]Reg network fail %d\n", ret );
        return (ret);
    }
    printf( "[INFO]Reg network success!\n" );
    return (ret);
}


/*SOCKETͨ�ŷ�ʽ��(����UDP/TCP),ģ���ʼ�� */
int nb_soctet_init( int socketId, const char* host, uint16_t port, int proto )
{
    int ret;
    nb_comm_init();
    ret = NB_MN316_socketCreate( 0, (char *) host, port, proto );
    if ( ret != AT_OK )
    {
        printf( "[INFO]NB_MN316_socketCreate fail\n" );
    }
    memcpy( g_host, host, strlen( host ) + 1 );
    g_port  = port;
    g_proto = proto;      
    return (ret);
}


/*UDP/TCPͨ�ŷ�ʽ��,ģ���ϱ����� */
int nb_socket_report( int socketId, const char* buf, int len )
{
    int ret;
    if ( buf == NULL || len <= 0 )
        return (-1);
    ret = NB_MN316_socketStrSend( socketId, buf, len ,
                                  g_host, g_port, g_proto);
    return (ret);
}

/*UDP/TCPͨ�ŷ�ʽ��,��ȡģ������ */
int nb_socket_recv( int socketId, char* buf, int len )
{
    int ret;
    if ( buf == NULL || len <= 0 )
        return (-1);
    ret = NB_MN316_socketStrRecv( socketId, buf, len );
    return (ret);
}

/*MQTTͨ�ŷ�ʽ��,ģ���ʼ�� */
int nb_mqtt_init( char* protocolVer )
{
    int ret;
    nb_comm_init();

    ret = NB_MN316_mqttOpen( protocolVer );
    if ( ret == AT_OK )
        printf( "[INFO]NB_MN316_mqtt open\n" );
    return (ret);
}


/*MQTTͨ�ŷ�ʽ��,ģ������ */
int nb_mqtt_conn( char * brokerAddress, uint16_t port, char *clientID, char *userName, char *password )
{
    int ret;

    ret = NB_MN316_mqttConnet( brokerAddress, port, clientID, userName, password );
    if ( ret == AT_OK )
        printf( "[INFO]NB_MN316_mqtt set config success\n" );
    return (ret);
}


/*MQTTͨ�ŷ�ʽ��,ģ�鶩����Ϣ */
int nb_mqtt_sub( char* topic )
{
    return (NB_MN316_mqttSub( topic ) );
}


/*MQTTͨ�ŷ�ʽ��,ģ���ϱ����� */
int nb_mqtt_pub( char* topic, char* buf )
{
    return (NB_MN316_mqttPub( topic, buf, strlen( buf ) ) );
}



/*
 * ע��ģ��URC�ϱ�֪ͨ��ͨ���ص�����ʵ��֪ͨ����
 */
void nb_urc_set( const struct at_urc *urc_table, uint32_t table_sz )
{
    at_set_urc_table( urc_table, table_sz );
}


int nb_deinit( void )
{
    NB_pwrdown();
    at.deinit();
    return (0);
}

