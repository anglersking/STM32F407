/*
 * **************************************
 * Copyright (c) 2020-2021 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include <at_log.h>
#include <stdio.h>
#include <string.h>
#include "nb_api.h"
#include "nb_mn316.h"


static at_response_t resp = RT_NULL;
int32_t at_init( at_config *config )
{
    rt_int32_t timeOut;
    if ( config->usart_port == 2 )
        at_client_init( "uart2", 512 );
    else if ( config->usart_port == 3 )
        at_client_init( "uart3", 512 );
    else
        return (-1);
    if ( rt_tick_from_millisecond( config->timeout ) < rt_tick_from_millisecond( 100 ) )
        timeOut = rt_tick_from_millisecond( 100 );
    else
        timeOut = rt_tick_from_millisecond( config->timeout );
    resp = at_create_resp( 1024, 0, timeOut );
    if ( !resp )
    {
        LOG_E( "No memory for response structure!" );
        return (-RT_ENOMEM);
    }
    return (0);
}


int32_t at_deinit( void )
{
    return (0);
}


int32_t at_cmd( int8_t *cmd, int32_t len, const char *suffix, char *resp_buf, int* resp_len )
{
    uint32_t	recvLen = 0;
    int			result;
    char		*ptr;
    result = RT_EOK;
    if ( at_exec_cmd( resp, (char *) cmd ) < 0 )
    {
        result = -RT_ERROR;
    }
    if ( suffix != NULL )
    {
        if ( at_resp_get_line_by_kw( resp, suffix ) <= 0 )
        {
            result = -RT_ERROR;
        }
    }

    if ( resp_buf != NULL && resp_len != NULL )
    {
        ptr = resp->buf;
        for ( int i = 0; i < resp->line_counts; i++ )
        {
            memcpy( resp_buf + recvLen, ptr, strlen( ptr ) );
            recvLen += strlen( ptr );
            resp_buf[recvLen++] = '\n';
            ptr		+= (strlen( ptr ) + 1);
        }
        *resp_len = recvLen;
    }
    return (result);
}


at_task at =
{
    .init	= at_init,
    .deinit = at_deinit,
    .cmd	= at_cmd,
};

