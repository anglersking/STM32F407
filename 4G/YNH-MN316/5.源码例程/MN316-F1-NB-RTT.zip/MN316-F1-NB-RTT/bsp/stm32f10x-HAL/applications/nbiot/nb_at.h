/*
 * **************************************
 * Copyright (c) 2020-2021 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#ifndef __LTE_AT_H__
#define __LTE_AT_H__

#define printf    rt_kprintf

#define  AT_DATA_LEN 1024
#define  AT_OK		0
#define  AT_FAILED	0

typedef struct __config {
    char		* name;
    uint32_t	usart_port;
    uint32_t	buardrate;
    uint32_t	user_buf_len;
    char		* cmd_begin;
    char		* line_end;
    uint32_t	mux_mode;
    uint32_t	timeout; /*command respond timeout */
}at_config;

typedef struct at_task {
    void (*step_callback)();
    int32_t (*init)( at_config *config );
    int32_t (*cmd)( int8_t * cmd, int32_t len, const char * suffix, char * resp_buf, int* resp_len );
    int32_t (*deinit)( void );
} at_task;

#endif
