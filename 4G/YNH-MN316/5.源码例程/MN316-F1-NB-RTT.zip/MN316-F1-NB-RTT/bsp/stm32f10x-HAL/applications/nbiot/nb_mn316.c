/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "nb_mn316.h"


extern at_task at;

static char    rbuf[AT_DATA_LEN];
static char    wbuf[AT_DATA_LEN];


char tmpbuf[AT_DATA_LEN] = { 0 }; /*transform to hex */


int hex_to_hexStr( const char *bufin, int len, char *bufout )
{
    int i = 0;
    if ( NULL == bufin || len <= 0 || NULL == bufout )
    {
        return (-1);
    }
    for ( i = 0; i < len; i++ )
    {
        sprintf( bufout + i * 2, "%02X", bufin[i] );
    }
    return (0);
}


void hexStr_to_hex( const unsigned char *source, unsigned char *dest, int sourceLen )
{
    short           i;
    unsigned char   highByte, lowByte;
    for ( i = 0; i < sourceLen; i += 2 )
    {
        highByte    = toupper( source[i] );
        lowByte     = toupper( source[i + 1] );
        if ( highByte > 0x39 )
            highByte -= 0x37;
        else
            highByte -= 0x30;
        if ( lowByte > 0x39 )
            lowByte -= 0x37;
        else
            lowByte -= 0x30;
        dest[i / 2] = (highByte << 4) | lowByte;
    }
    return;
}


int32_t NB_checkDevice( void )
{
    int32_t res = 0;
    res = at.cmd( (int8_t *) AT_NB_at, strlen( AT_NB_at ), "OK", NULL, NULL );
    if ( res == 0 )
    {
        printf( "[INFO]REBOOT RESPONSE SUCCESS\r\n" );
    }
    return (res);
}


/*���û��� */
int32_t NB_setATI( uint8_t enable )
{
    int     ret;
    char    buf[64];
    if ( enable == 0 )
    {
        char *cmd = "ATE0";
        snprintf( buf, sizeof(buf), "%s", cmd );
        ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    }
    else
    {
        char *cmd = "ATE1";
        snprintf( buf, sizeof(buf), "%s", cmd );
        ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    }
    return (ret);
}


int32_t NB_pwrdown( void )
{
    int32_t res = 0;
    res = at.cmd( (int8_t *) AT_NB_pwrdown, strlen( AT_NB_pwrdown ), "OK", NULL, NULL );
    if ( res == 0 )
    {
        printf( "[INFO]PWRDOWN RESPONSE SUCCESS\r\n" );
    }
    return (res);
}


int32_t NB_getCimi()
{
    char    *cmd = "AT+CIMI";
    char    recvBuf[64];
    int     recvLen;
    int     ret;
    ret = at.cmd( (int8_t *) cmd, strlen( cmd ), "OK", recvBuf, &recvLen );
    if ( recvLen < 64 )
    {
        recvBuf[recvLen] = '\0';
        printf( "[INFO]CIMI:%s", recvBuf );
    }
    return (ret);
}


int32_t NB_getCGSN()
{
    char    *cmd = "AT+CGSN=1";
    char    recvBuf[64];
    int     recvLen;
    int     ret;
    ret = at.cmd( (int8_t *) cmd, strlen( cmd ), "OK", recvBuf, &recvLen );
    if ( recvLen < 64 )
    {
        recvBuf[recvLen] = '\0';
        printf( "[INFO]CGSN:%s", recvBuf );
    }
    return (ret);
}


int32_t NB_checkCsq( void )
{
    char *cmd = "AT+CSQ";
    return (at.cmd( (int8_t *) cmd, strlen( cmd ), "+CSQ:", NULL, NULL ) );
}


/*����IP��ַ */
int32_t NB_CIMI( void )
{
    char *cmd = "AT+CGPADDR";
    return (at.cmd( (int8_t *) cmd, strlen( cmd ), "+CGPADDR:0,", NULL, NULL ) );
}


int32_t NB_netstat( void )
{
    char *cmd = "AT+CGATT?";
    return (at.cmd( (int8_t *) cmd, strlen( cmd ), "CGATT: 1", NULL, NULL ) );
}


int32_t NB_queryIp( void )
{
    char *cmd = "AT+CGPADDR=0";
    return (at.cmd( (int8_t *) cmd, strlen( cmd ), "+CGPADDR", NULL, NULL ) );
}


int32_t NB_getCereg( void )
{
    char    *cmd = "AT+CEREG?";
    char    recvBuf[64];
    int     recvLen;
    int     ret;
    ret = at.cmd( (int8_t *) cmd, strlen( cmd ), "0,1", recvBuf, &recvLen );
    if ( recvLen < 64 )
    {
        recvBuf[recvLen] = '\0';
        printf( "[INFO]cereg:%s\r\n", recvBuf );
    }
    return (ret);
}


/*
 * proto =17ΪTCP =6ΪUDP
 */
int32_t NB_MN316_socketCreate( uint8_t socketId, char* host, uint16_t port, int proto )
{
    int socket;
    int rbuflen = AT_DATA_LEN;

    const char  *cmdudp     = "AT+NSOCR=\"DGRAM\",17,2334,1";   /*udp */
    const char  *cmd1tcp    = "AT+NSOCR=\"STREAM\",6,2335,1";   /*tcp */
    const char  *cmd3cfg    = "AT+NSOCFG=0,0,2";                /*�ַ����շ� */
    int         ret;
    char        buf[64];
    int         cmd_len;
    int         timeOut = 0;

    if ( proto != 17 && proto != 6 )
    {
        printf( "[ERROR]proto invalid!" );
        return (-1);
    }
    if ( socketId > 4 )
    {
        printf( "[ERROR]socketId invalid!" );
        return (-1);
    }
    memset( rbuf, 0, AT_DATA_LEN );

    if ( proto == 17 )
    {
        cmd_len = snprintf( buf, sizeof(buf), "%s", cmdudp );       /*udp */
    }
    else if ( proto == 6 )
    {
        cmd_len = snprintf( buf, sizeof(buf), "%s", cmd1tcp );      /*tcp */
    }
    (void) cmd_len;
    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        printf( "[ERROR]socketCreate fail0,ret=%d", ret );
        return (ret);
    }

    if ( proto == 6 )
    {
        /*tcp */
        cmd_len = snprintf( buf, sizeof(buf), "AT+NSOCO=0,%s,%d", host, port );
        ret     = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
        if ( ret < 0 )
        {
            printf( "[ERROR]socketCreate fail1,ret=%d", ret );
            return (ret);
        }
    }

    cmd_len = snprintf( buf, sizeof(buf), "%s", cmd3cfg );
    ret     = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        printf( "[ERROR]socketCreate fail1,ret=%d", ret );
        return (ret);
    }

    return (0);
}


int32_t NB_MN316_socketStrSend( int32_t socketId, const char  *inData, uint32_t len,
                                char* host, uint16_t port, int proto )
{
    int     ret;
    int     data_len = strlen( inData );
    char    buf[256];
    if ( buf == NULL || data_len > AT_MAX_PAYLOADLEN || socketId >= MAX_SOCK_NUM )
    {
        printf( "[ERROR]invalid args" );
        return (-1);
    }

    if ( proto == 6 )
    {
        /*AT+NSOSD=0,17,48656C6C6F2059654E697520494F540D0A */
        snprintf( buf, AT_DATA_LEN, "AT+NSOSD=%d,%d,%s", (int) socketId, data_len, inData );
    }
    else if ( proto == 17 )
    {
        /*AT+NSOST=0,123.207.210.43,9999,10,"0123445679" */
        snprintf( buf, AT_DATA_LEN, "AT+NSOST=%d,%s,%d,%d,%s", (int) socketId, host, port, data_len, inData );
    }

    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        printf( "[ERROR]NB_MN316_socketStrSend fail %d\r\n", ret );
        return (ret);
    }
    return (len);
}


int32_t NB_MN316_socketStrRecv( int32_t socketId, char  *outData, uint32_t len )
{
    int     ret;
    int     data_len = len;
    char    buf[256];

    snprintf( buf, AT_DATA_LEN, "AT+NSORF=%d,%d", (int) socketId, len );

    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", outData, &data_len );
    if ( ret < 0 )
    {
        printf( "[ERROR]NB_MN316_socketStrRecv fail %d\r\n", ret );
        return (ret);
    }
    return (len);
}


int32_t NB_MN316_sockClose( int32_t socketId )
{
    char    *cmd = "AT+NSOCL=";
    int     ret;
    char    buf[64];
    if ( (socketId >= MAX_SOCK_NUM) )
    {
        printf( "[ERROR]link id %ld invalid", socketId );
        return (AT_FAILED);
    }
    snprintf( buf, sizeof(buf), "%s%d", cmd, socketId );
    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    return (ret);
}


/*
 * ����mqtt
 */
int32_t NB_MN316_mqttOpen( char* protocolVer )
{
    int     ret;
    char    buf[256];
    return (AT_OK);
}


/*
 * AT+QMTCONN=0,"clientExample"
 */
int32_t NB_MN316_mqttConnet( char *brokerAddress, uint16_t port,
                             char *clientID, char * userName, char * password )
{
    int     ret;
    char    buf[256];

    /*AT+MQTTCFG="123.207.210.43",1883,"clientExample",60,"","",1,0 */
    if ( userName != NULL && password != NULL )
    {
        snprintf( buf, sizeof(buf), "AT+MQTTCFG=\"%s\",%d,\"%s\",60,\"%s\",\"%s\",1,0",
                  brokerAddress, port,
                  clientID, userName, password );
    }
    else
    {
        snprintf( buf, sizeof(buf), "AT+MQTTCFG=\"%s\",%d,\"%s\",60,\"\",\"\",1,0",
                  brokerAddress, port, clientID );
    }
    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        printf( "[ERROR]MQTTCON ERROR" );
        return (ret);
    }

    if ( userName != NULL && password != NULL )
    {
        snprintf( buf, sizeof(buf), "AT+MQTTOPEN=1,1,0,0,0,\"\",\"\"" );
    }
    else
    {
        snprintf( buf, sizeof(buf), "AT+MQTTOPEN=0,0,0,0,0,\"\",\"\"" );
    }
    ret = at.cmd( (int8_t *) buf, strlen( buf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        printf( "[ERROR]MQTTCON ERROR" );
        return (ret);
    }
    return (AT_OK);
}


/*
 * ����MQTT��Ϣ
 * AT+MQTTSUB="topic/example_8808",0
 */
int32_t NB_MN316_mqttSub( char* topic )
{
    int ret;

    snprintf( wbuf, sizeof(wbuf), "AT+MQTTSUB=\"%s\",0", topic );
    ret = at.cmd( (int8_t *) wbuf, strlen( wbuf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        return (ret);
    }
    return (AT_OK);
}


/*
 * ����MQTT��Ϣ
 * AT+MQTTPUB="topic/example_8808",0,0,0,0,"hello yeniu!I am MN316"
 * AT+MQTTPUB="$sys/WtF1aQE659/EC800816/thing/property/post",0,0,0,133,7b226964223a22313233222c2276657273696f6e223a22312e30222c22706172616d73223a7b2243757272656e7454656d7065726174757265223a7b2276616c7565223a31312e337d2c224c696768744c7578223a7b2276616c7565223a313030302e337d2c22536f696c4d6f697374757265223a7b2276616c7565223a35312e347d7d7d
 */
int32_t NB_MN316_mqttPub( char* topic,
                          char* msg,
                          uint32_t msgLen )
{
    int ret;

    hex_to_hexStr( msg, msgLen, tmpbuf );
    snprintf( wbuf, sizeof(wbuf), "AT+MQTTPUB=\"%s\",0,0,0,%d,\"%s\"", topic, msgLen, tmpbuf );
    ret = at.cmd( (int8_t *) wbuf, strlen( wbuf ), "OK", NULL, NULL );
    if ( ret < 0 )
    {
        return (ret);
    }
    return (AT_OK);
}

