/*
 * **************************************
 * Copyright (c) 2020-2021 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#ifndef __USER_TASK_H__
#define __USER_TASK_H__
#include "nb_api.h"
#include "nb_mn316.h"

typedef enum
{
    NBDemoPath_NONE,
    NBDemoPath_UDP,
    NBDemoPath_TCP,
    NBDemoPath_MQTT,
    NBDemoPath_ONENET,
    NBDemoPath_ALIYUN,
    NBDemoPath_END
}NBAppDemoPath_t;

#endif
