/*
 * **************************************
 * Copyright (c) 2018-2019, Ұţ������.
 *      All rights reserved.
 * **************************************
 */
#include "led.h"

#define LED1_PIN    (GPIO_Pin_5)
#define LED1_GPIO   (GPIOB)

#define LED2_PIN    (GPIO_Pin_5)
#define LED2_GPIO   (GPIOE)

void LED_init()
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOE, ENABLE );  /*ʹ��PB,PE�˿�ʱ�� */
    GPIO_InitStructure.GPIO_Pin     = LED1_PIN;
    GPIO_InitStructure.GPIO_Speed   = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode    = GPIO_Mode_AF_PP;                              /*����������� */
    GPIO_Init( LED1_GPIO, &GPIO_InitStructure );                                    /*��ʼ��*/

    GPIO_InitStructure.GPIO_Pin     = LED2_PIN;
    GPIO_InitStructure.GPIO_Speed   = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode    = GPIO_Mode_AF_PP;
    GPIO_Init( LED2_GPIO, &GPIO_InitStructure );
}


u8 LED_set( LED_INDEX index, LED_STATE state )
{
    if ( index == LED_INDEX_1 )
    {
        /*LED1 */
        if ( state == LED_STATE_OFF )
        {   /*�ر� */
            GPIO_WriteBit( LED1_GPIO, LED1_PIN, Bit_SET );
        }
        else if ( state == LED_STATE_ON )
        {   /*�� */
            GPIO_WriteBit( LED1_GPIO, LED1_PIN, Bit_RESET );
        }
    }
    else if ( index == LED_INDEX_2 )
    {
        /*LED2 */
        if ( state == LED_STATE_OFF )
        {   /*�ر� */
            GPIO_WriteBit( LED2_GPIO, LED1_PIN, Bit_SET );
        }
        else if ( state == LED_STATE_ON )
        {   /*�� */
            GPIO_WriteBit( LED1_GPIO, LED1_PIN, Bit_RESET );
        }
    }
    else
    {
        return (RETURN_ERROR);
    }
    return (RETURN_OK);
}

