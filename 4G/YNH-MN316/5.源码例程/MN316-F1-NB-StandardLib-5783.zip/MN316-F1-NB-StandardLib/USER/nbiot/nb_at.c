/*
 * **************************************
 * Copyright (c) 2023-2025 Ұţ������
 *      All rights reserved.
 * **************************************
 */
#include <stdio.h>
#include <string.h>
#include "nb_api.h"
#include "nb_mn316.h"
#include "system.h"
#include "string.h"
#include "nb_at.h"

static uint16_t             uartxRxstate    = 0;
static uint16_t             uartxTxstate    = 0;
static uint8_t              uartxRxBuf[512];
static uint8_t              uartxTxBuf[512];
static uint8_t              aRxBuffer[128];
static const struct at_urc  *gUrcTable;
static uint8_t              gUrcTableSize;

uint8_t NBAT_checkUrc( uint8_t *outResponse, uint32_t len );


#define    UARTX_RECV_END (0x8000)

void USART2_IRQHandler( void )
{
    uint8_t res;

    if ( USART_GetFlagStatus( USART2, USART_FLAG_ORE ) != RESET )
    {
        USART_ClearFlag( USART2, USART_FLAG_ORE );
    }
    if ( USART_GetFlagStatus( USART2, USART_FLAG_PE ) != RESET )
    {
        USART_ClearFlag( USART2, USART_FLAG_PE );
    }
    if ( USART_GetFlagStatus( USART2, USART_FLAG_FE ) != RESET )
    {
        USART_ClearFlag( USART2, USART_FLAG_FE );
    }
    if ( USART_GetFlagStatus( USART2, USART_FLAG_NE ) != RESET )
    {
        USART_ClearFlag( USART2, USART_FLAG_NE );
    }

    if ( USART_GetFlagStatus( USART2, USART_FLAG_RXNE ) != RESET )
    {
        USART_ClearFlag( USART2, USART_FLAG_RXNE );
        /*printf( "a" );*/
        res = (uint8_t) (USART2->DR & (uint16_t) 0x00FF);
        if ( (uartxRxstate & UARTX_RECV_END) == 0 )
        {
            if ( uartxRxstate == 0x00 )
            {
                memset( (uint8_t *) uartxRxBuf, 0x00, sizeof(uartxRxBuf) );
            }
            if ( uartxRxstate < sizeof(uartxRxBuf) )
            {
                TIM2->CNT = 0;                              /*��������� */
                TIM_Cmd( TIM2, ENABLE );
                uartxRxBuf[uartxRxstate++] = res;           /*��¼���յ���ֵ */
            }
            else
            {
                uartxRxstate |= UARTX_RECV_END;             /*ǿ�Ʊ�ǽ������ */
            }
        }
    }
}


void TIM2_IRQHandler( void )
{
    /*printf("[INFO]timeout\r\n"); */
    if ( (uartxRxstate & 0x7FFF) != 0 )
    {
        if ( uartxTxstate == 1 )
            uartxRxstate |= UARTX_RECV_END;                 /*ָ����Ӧ */
        else if ( uartxTxstate == 0 )
        {
            /*���URC */
            NBAT_checkUrc( uartxRxBuf, uartxRxstate );
        }
    }
    if ( TIM_GetITStatus( TIM2, TIM_IT_Update ) != RESET )  /*���TIM�����жϷ������ */
    {
        TIM_ClearITPendingBit( TIM2, TIM_IT_Update );       /*���TIMx�����жϱ�־ */
    }
}


/*3ms��ʱ�� */
static void TIM2_init( void )
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef        NVIC_InitStructure;

    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM2, ENABLE );                  /*ʱ��ʹ�� */

    /*��ʱ��TIM2��ʼ�� */
    TIM_TimeBaseStructure.TIM_Period        = 100 * 3 - 1;                  /*��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ */
    TIM_TimeBaseStructure.TIM_Prescaler     = 10 * 72 - 1;                  /*����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ */
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;                 /*����ʱ�ӷָ�:TDTS = Tck_tim */
    TIM_TimeBaseStructure.TIM_CounterMode   = TIM_CounterMode_Up;           /*TIM���ϼ���ģʽ */
    TIM_TimeBaseInit( TIM2, &TIM_TimeBaseStructure );                       /*����ָ���Ĳ�����ʼ��TIMx��ʱ�������λ */

    TIM_ITConfig( TIM2, TIM_IT_Update, ENABLE );                            /*ʹ��ָ����TIM3�ж�,���������ж� */

    /*�ж����ȼ�NVIC���� */
    NVIC_InitStructure.NVIC_IRQChannel                      = TIM2_IRQn;    /*TIM2�ж� */
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority    = 0;            /*��ռ���ȼ�0�� */
    NVIC_InitStructure.NVIC_IRQChannelSubPriority           = 3;            /*�����ȼ�3�� */
    NVIC_InitStructure.NVIC_IRQChannelCmd                   = ENABLE;       /*IRQͨ����ʹ�� */
    NVIC_Init( &NVIC_InitStructure );                                       /*��ʼ��NVIC�Ĵ��� */

    TIM_Cmd( TIM2, DISABLE );
}


void UARTx_init( uint32_t bound )
{
    /*GPIO�˿����� */
    GPIO_InitTypeDef    GPIO_InitStructure;
    USART_InitTypeDef   USART_InitStructure;
    NVIC_InitTypeDef    NVIC_InitStructure;

    RCC_APB1PeriphClockCmd( RCC_APB1Periph_USART2 | RCC_APB2Periph_GPIOA, ENABLE );     /*ʹ��USART1��GPIOAʱ�� */

    /*USART1_TX   GPIOA.9 */
    GPIO_InitStructure.GPIO_Pin     = GPIO_Pin_2;                                       /*PA.9 */
    GPIO_InitStructure.GPIO_Speed   = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode    = GPIO_Mode_AF_PP;                                  /*����������� */
    GPIO_Init( GPIOA, &GPIO_InitStructure );                                            /*��ʼ��GPIOA.9 */

    /*USART1_RX	  GPIOA.10��ʼ�� */
    GPIO_InitStructure.GPIO_Pin     = GPIO_Pin_3;                                       /*PA10 */
    GPIO_InitStructure.GPIO_Mode    = GPIO_Mode_IN_FLOATING;                            /*�������� */
    GPIO_Init( GPIOA, &GPIO_InitStructure );                                            /*��ʼ��GPIOA.10 */

    /*Usart2 NVIC ���� */
    NVIC_InitStructure.NVIC_IRQChannel                      = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority    = 3;                        /*��ռ���ȼ�3 */
    NVIC_InitStructure.NVIC_IRQChannelSubPriority           = 3;                        /*�����ȼ�3 */
    NVIC_InitStructure.NVIC_IRQChannelCmd                   = ENABLE;                   /*IRQͨ��ʹ�� */
    NVIC_Init( &NVIC_InitStructure );                                                   /*����ָ���Ĳ�����ʼ��VIC�Ĵ��� */

    /*USART ��ʼ������ */

    USART_InitStructure.USART_BaudRate              = bound;                            /*���ڲ����� */
    USART_InitStructure.USART_WordLength            = USART_WordLength_8b;              /*�ֳ�Ϊ8λ���ݸ�ʽ */
    USART_InitStructure.USART_StopBits              = USART_StopBits_1;                 /*һ��ֹͣλ */
    USART_InitStructure.USART_Parity                = USART_Parity_No;                  /*����żУ��λ */
    USART_InitStructure.USART_HardwareFlowControl   = USART_HardwareFlowControl_None;   /*��Ӳ������������ */
    USART_InitStructure.USART_Mode                  = USART_Mode_Rx | USART_Mode_Tx;    /*�շ�ģʽ */

    USART_Init( USART2, &USART_InitStructure );                                         /*��ʼ������2 */
    USART_ITConfig( USART2, USART_IT_RXNE, ENABLE );                                    /*�������ڽ����ж� */
    USART_Cmd( USART2, ENABLE );                                                        /*ʹ�ܴ���2 */
}


void UARTx_write( uint8_t *buf, uint16_t length )
{
    uint16_t i;
    for ( i = 0; i < length; i++ )                                                      /*ѭ���������� */
    {
        while ( (USART2->SR & 0x40) == 0 )
            ;
        USART2->DR = buf[i];
    }
}


void NBAT_init( uint32_t bound )
{
    UARTx_init( bound );
    TIM2_init();
}


char* NBAT_checkCmd( char *str )
{
    char *strx = 0;
    if ( uartxRxstate & UARTX_RECV_END )
    {                                               /*���յ�һ�������� */
        uartxRxBuf[uartxRxstate & 0x7FFF]   = 0;    /*���ӽ����� */
        strx                                = (char *) strstr( (const char *) uartxRxBuf, (const char *) str );
    }
    return (strx);
}


int NBAT_sendBuf( char *buf, char *ack, uint32_t waittime, uint8_t *outResponse )
{
    uint8_t     res     = 0;
    uint16_t    sendLen = 0;
    if ( strlen( buf ) > sizeof(uartxTxBuf) )
    {
        printf( "NBAT_sendCmd Len is %d\r\n", strlen( buf ) );
        return (2);
    }
    /*��Ϊ0��ʾ��URC���ݽ��� */
    while ( uartxRxstate != 0 )
        ;

    /*���ͱ�־λ��λ */
    uartxTxstate = 1;

    sendLen = sprintf( (char *) uartxTxBuf, "%s", buf );
    UARTx_write( uartxTxBuf, sendLen );

    waittime *= 10 * 100;
    if ( ack && waittime )
    {
        while ( --waittime )
        {
            DELAY_us( 10 );
            if ( uartxRxstate & UARTX_RECV_END )
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    if ( outResponse != NULL )
                    {
                        memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                        outResponse[uartxRxstate & 0x7FFF] = 0;
                    }
                    /*�õ���Ч���� */
                    uartxRxstate = 0;
                    break;
                }
            }
        }
        if ( waittime == 0 )
            res = 1;
    }
    uartxRxstate    = 0;
    uartxTxstate    = 0;
    return (res);
}


uint8_t NBAT_sendCmd( char *cmd, char *ack, uint32_t waittime, uint8_t *outResponse )
{
    uint8_t     res     = 0;
    uint16_t    sendLen = 0;
    if ( strlen( cmd ) > sizeof(uartxTxBuf) )
    {
        printf( "NBAT_sendCmd Len is %d\r\n", strlen( cmd ) );
        return (2);
    }
    /*��Ϊ0��ʾ��URC���ݽ��� */
    while ( uartxRxstate != 0 )
        ;
    uartxTxstate = 1;                                           /*���ͱ�־λ��λ */

    sendLen = sprintf( (char *) uartxTxBuf, "%s", cmd );
    UARTx_write( uartxTxBuf, sendLen );                         /*�������� */
    UARTx_write( AT_LINE_END, strlen( AT_LINE_END ) - 1 );      /*���ͽ������� */

    waittime *= 10 * 100;
    if ( ack && waittime )                                      /*��Ҫ�ȴ�Ӧ�� */
    {
        while ( --waittime )                                    /*�ȴ�����ʱ */
        {
            DELAY_us( 10 );
            if ( uartxRxstate & UARTX_RECV_END )                /*���յ��ڴ���Ӧ���� */
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    if ( outResponse != NULL )
                    {
                        memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                        outResponse[uartxRxstate & 0x7FFF] = 0;
                    }
                    uartxRxstate = 0;
                    /*�õ���Ч���� */
                    break;
                }
            }
        }
        if ( waittime == 0 )
            res = 1;
    }
    uartxRxstate    = 0;
    uartxTxstate    = 0;
    return (res);
}


uint8_t NBAT_checkUrc( uint8_t *outResponse, uint32_t len )
{
    uint8_t idx;
    uint8_t *strPtr     = outResponse;
    uint8_t strLen      = 0;
    char    * strStart  = NULL;
    char    * strEnd    = NULL;
    /*printf( "NBAT_checkUrc:" ); */
    for ( idx = 0; idx < gUrcTableSize; idx++ )
    {
        strStart = strstr( (char *) strPtr, gUrcTable[idx].cmd_prefix );
        if ( strStart != 0 )
        {
            strLen  = strlen( gUrcTable[idx].cmd_prefix );
            strEnd  = strstr( (char *) strPtr + strLen, gUrcTable[idx].cmd_suffix );
            strLen  = strEnd - strStart + strlen( gUrcTable[idx].cmd_suffix );
            if ( strEnd != 0 )
                gUrcTable[idx].func( (const char *) strPtr, strLen );
            strPtr += strLen;
        }
    }
    uartxRxstate = 0;   /*�����URC֮������ */
    return (1);
}


uint8_t NBAT_recvData( char *ack, uint16_t waittime, uint8_t *outResponse )
{
    uint8_t res = 0;
    if ( (uartxRxstate & UARTX_RECV_END) == 0 )
        return (2);
    if ( ack && waittime )                              /*��Ҫ�ȴ�Ӧ�� */
    {
        /*�ȴ�����ʱ */
        do
        {
            DELAY_ms( 10 );
            if ( uartxRxstate & UARTX_RECV_END )        /*���յ��ڴ���Ӧ���� */
            {
                if ( NBAT_checkCmd( ack ) )
                {
                    memcpy( outResponse, uartxRxBuf, uartxRxstate & 0x7FFF );
                    outResponse[uartxRxstate & 0x7FFF]  = 0;
                    uartxRxstate                        = 0;
                    break;                              /*�õ���Ч���� */
                }
            }
        }
        while ( --waittime );
        if ( waittime == 0 )
            res = 1;
    }
    return (res);
}


/*static at_response_t resp = RT_NULL; */
int32_t at_init( at_config *config )
{
    NBAT_init( config->buardrate );
    return (0);
}


int32_t at_deinit( void )
{
    return (0);
}


int32_t at_cmd( int8_t *cmd, int32_t len, const char *suffix, char *resp_buf, int* resp_len )
{
    uint32_t    recvLen = 0;
    int         result;
    result = NBAT_sendCmd( (char *) cmd, (char *) suffix, 100, (uint8_t *) resp_buf );
    return (result);
}


int32_t at_buf( int8_t *buf, int32_t len, const char *suffix, char *resp_buf, int* resp_len )
{
    uint32_t    recvLen = 0;
    int         result;
    result = NBAT_sendBuf( (char *) buf, (char *) suffix, 100, (uint8_t *) resp_buf );
    return (result);
}


int32_t at_set_urc_table( const struct at_urc *urc_table, uint32_t table_sz )
{
    uint8_t idx;

    if ( table_sz > 5 )
        return (-1);
    for ( idx = 0; idx < table_sz; idx++ )
    {
        if ( urc_table[idx].cmd_prefix == NULL || urc_table[idx].cmd_suffix == NULL )
        {
            printf( "[ERROR]at_set_urc_table fail\r\n" );
            return (-2);
        }
    }
    gUrcTable       = urc_table;
    gUrcTableSize   = table_sz;
    return (0);
}


at_task at =
{
    .init       = at_init,
    .deinit     = at_deinit,
    .cmd        = at_cmd,
    .sendBuf    = at_buf,
};

