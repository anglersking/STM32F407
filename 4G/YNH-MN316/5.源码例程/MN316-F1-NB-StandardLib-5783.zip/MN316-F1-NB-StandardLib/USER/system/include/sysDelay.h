#ifndef __DELAY_H
#define __DELAY_H
#include "system.h"

void DELAY_init( uint8_t SYSCLK );


void DELAY_us( uint32_t nus );


uint32_t DELAY_ms( uint32_t nms );

#endif

