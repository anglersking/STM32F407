#ifndef __SYS_H__
#define __SYS_H__
#ifdef STM32F103xE
#include "stm32f1xx.h"
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_tim.h"
#elif STM32F4XX
#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_tim.h"
#endif
#include "stm32f10x.h"
#include "string.h"
#include "stdio.h"
#include "sysDelay.h"

#ifdef DEBUG
#include "debug.h"
#else
#define DEBUG_init()
#define DEBUG_switch( x, y, z )
#endif

#define printf printf

typedef uint8_t		uint8_t;
typedef uint16_t	uint16_t;
typedef uint32_t	uint32_t;
typedef int16_t		int16_t;
typedef int32_t		int32_t;

typedef uint8_t		u8;
typedef uint16_t	u16;
typedef uint32_t	u32;
typedef int32_t		int32;

#define RETURN_OK		(0)
#define RETURN_ERROR	(1)

//#define GPIO_SPEED_HIGH GPIO_SPEED_FREQ_HIGH    

//void Error_Handler( void );
//#define _Error_Handler() Error_Handler()
void _Error_Handler( char * file, int line );

#define REQUIRE_noErr( ERR, LABEL, ACTION ) \
    do                                      \
    {                                       \
        if ( ERR )                          \
        {                                   \
            { ACTION; }                     \
            goto LABEL;                     \
        }                                   \
    } while ( 0 )
#endif

